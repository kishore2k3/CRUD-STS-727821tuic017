package com.database.demo.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.database.demo.model.Employee;

public interface EmpRep extends JpaRepository<Employee,Long> {

}
