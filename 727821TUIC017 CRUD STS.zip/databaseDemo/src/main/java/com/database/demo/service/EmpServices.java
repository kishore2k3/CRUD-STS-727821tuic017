package com.database.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.database.demo.model.Employee;
import com.database.demo.repository.EmpRep;

@Service
public class EmpServices {
	@Autowired
	EmpRep emprep;
	public List<Employee> getAllEmployees()
	{
		List<Employee> empData=emprep.findAll();
		return empData;
	}
//	public Optional<Employee> getByIdEmployees(long k)
//	{
//		Optional<Employee> empData=emprep.findById(k);
//		return empData;
//	}
	public Employee getByIdEmployees(long k)
	{
		Employee empData=emprep.findById(k).get();
		return empData;
	}
	public Employee saveEmployee(Employee e){
		return emprep.save(e);
	}
	public void deleteEmp(long k)
	{
		emprep.deleteById(k);
	}
}