package com.CRUDapp.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.CRUDapp.demo.model.Student;


public interface CRUDrepository extends JpaRepository<Student,Integer> {

}
