package com.CRUDapp.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CruDappApplication {

	public static void main(String[] args) {
		SpringApplication.run(CruDappApplication.class, args);
	}

}
